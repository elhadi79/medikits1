# MediKits AI-Powered Dropshipping Platform

This project leverages AI for an advanced dropshipping experience.

## How to Deploy
Use GitHub to manage the code and Netlify for deployment.